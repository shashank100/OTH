(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _underscore = require('underscore');

var AboutHomeActions = (function () {
	function AboutHomeActions() {
		_classCallCheck(this, AboutHomeActions);

		this.generateActions('getName');
	}

	_createClass(AboutHomeActions, [{
		key: 'getUser',
		value: function getUser(credentials) {
			var _this = this;

			$.ajax({
				type: 'POST',
				url: '/getUserInfo',
				data: { id: credentials.userId }
			}).done(function (data) {
				if (data.exist == false) {
					//handle redirect, user does not exist
				} else {
						AboutHomeStore.getName(data);
					}
			}).fail(function (jqXhr) {
				_this.actions.loginFormFail(data.message);
			});
		}
	}]);

	return AboutHomeActions;
})();

exports['default'] = _alt2['default'].createActions(AboutHomeActions);
module.exports = exports['default'];

},{"../alt":4,"underscore":"underscore"}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _underscore = require('underscore');

var LoginFormActions = (function () {
	function LoginFormActions() {
		_classCallCheck(this, LoginFormActions);

		this.generateActions('loginFormSuccess', 'loginFormFail', 'invalidEmail', 'invalidPassword', 'updateEmail', 'updatePassword', 'signUp');
	}

	_createClass(LoginFormActions, [{
		key: 'login',
		value: function login(credentials) {
			var _this = this;

			$.ajax({
				type: 'POST',
				url: '/authenticate',
				data: { email: credentials.email, password: credentials.password }
			}).done(function (data) {
				if (data.exist == false) {
					_this.actions.loginFormFail(data.message);
				} else {
					(0, _underscore.assign)(credentials, data);
					_this.actions.loginFormSuccess(credentials);
				}
			}).fail(function (jqXhr) {
				_this.actions.loginFormFail(data.message);
			});
		}
	}]);

	return LoginFormActions;
})();

exports['default'] = _alt2['default'].createActions(LoginFormActions);
module.exports = exports['default'];

},{"../alt":4,"underscore":"underscore"}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _underscore = require('underscore');

var SignUpFormActions = (function () {
	function SignUpFormActions() {
		_classCallCheck(this, SignUpFormActions);

		this.generateActions('signUpFormSuccess', 'signUpFormFail', 'invalidEmail', 'invalidPassword', 'invalidNumber', 'invalidUsername', 'updateEmail', 'updatePassword', 'updateUsername', 'updateNumber', 'login');
	}

	_createClass(SignUpFormActions, [{
		key: 'signup',
		value: function signup(credentials) {
			var _this = this;

			$.ajax({
				type: 'POST',
				url: '/register',
				data: { name: credentials.name, email: credentials.email, password: credentials.password, number: credentials.number }
			}).done(function (data) {
				if (data.register == false) {
					_this.actions.signUpFormFail(data.message);
				} else {
					(0, _underscore.assign)(credentials, data);
					_this.actions.signUpFormSuccess(credentials);
				}
			}).fail(function (jqXhr) {
				_this.actions.signUpFormFail(data.message);
			});
		}
	}]);

	return SignUpFormActions;
})();

exports['default'] = _alt2['default'].createActions(SignUpFormActions);
module.exports = exports['default'];

},{"../alt":4,"underscore":"underscore"}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _alt = require('alt');

var _alt2 = _interopRequireDefault(_alt);

exports['default'] = new _alt2['default']();
module.exports = exports['default'];

},{"alt":"alt"}],5:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Header = require('./Header');

var _Header2 = _interopRequireDefault(_Header);

var _Footer = require('./Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _reactRouter = require('react-router');

var _reactRouter2 = _interopRequireDefault(_reactRouter);

var _storesAboutHomeStore = require('../stores/AboutHomeStore');

var _storesAboutHomeStore2 = _interopRequireDefault(_storesAboutHomeStore);

var _actionsAboutHomeActions = require('../actions/AboutHomeActions');

var _actionsAboutHomeActions2 = _interopRequireDefault(_actionsAboutHomeActions);

var AboutHome = (function (_React$Component) {
	_inherits(AboutHome, _React$Component);

	function AboutHome(props) {
		_classCallCheck(this, AboutHome);

		_get(Object.getPrototypeOf(AboutHome.prototype), 'constructor', this).call(this, props);
		this.state = _storesAboutHomeStore2['default'].getState();
		this.onChange = this.onChange.bind(this);
	}

	_createClass(AboutHome, [{
		key: 'componentDidMount',
		value: function componentDidMount() {
			_storesAboutHomeStore2['default'].listen(this.onChange);
			_actionsAboutHomeActions2['default'].getUser({ userId: this.props.params.id });
		}
	}, {
		key: 'componentWillMount',
		value: function componentWillMount() {
			_storesAboutHomeStore2['default'].unlisten(this.onChange);
		}
	}, {
		key: 'componentDidUpdate',
		value: function componentDidUpdate(prevProps) {
			if (prevProps.params.id !== this.props.params.id) {
				_actionsAboutHomeActions2['default'].getUser({ userId: this.props.params.id });
			}
		}
	}, {
		key: 'onChange',
		value: function onChange(state) {
			this.setState(state);
		}
	}, {
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'container-fluid loginPage registerPage' },
				_react2['default'].createElement(_Header2['default'], null),
				_react2['default'].createElement(
					'div',
					{ className: 'row pDetails' },
					_react2['default'].createElement(
						'div',
						{ className: 'pDetailsInnerWrapper' },
						_react2['default'].createElement(
							'center',
							null,
							_react2['default'].createElement(
								'ul',
								null,
								_react2['default'].createElement(
									'li',
									{ className: 'activeLiPdetails' },
									'About Your Home'
								),
								_react2['default'].createElement(
									'li',
									null,
									'Documentation'
								),
								_react2['default'].createElement(
									'li',
									null,
									'Your Contact @ CF'
								)
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-sm-12 aboutYourHome' },
							_react2['default'].createElement(
								'label',
								null,
								'Hi ',
								this.state.name,
								', to start with tell us about your new home'
							),
							_react2['default'].createElement(
								'div',
								{ className: 'formWrap' },
								_react2['default'].createElement(
									'span',
									null,
									'Address Line 1:'
								),
								_react2['default'].createElement('input', { type: 'text', placeholder: '' }),
								_react2['default'].createElement(
									'span',
									null,
									'Address Line 1:'
								),
								_react2['default'].createElement('input', { type: 'text', placeholder: '' }),
								_react2['default'].createElement(
									'div',
									{ className: 'col-sm-4 l' },
									_react2['default'].createElement(
										'span',
										null,
										'Town/City:'
									),
									_react2['default'].createElement('input', { type: 'text', placeholder: '' })
								),
								_react2['default'].createElement(
									'div',
									{ className: 'col-sm-4' },
									_react2['default'].createElement(
										'span',
										null,
										'State:'
									),
									_react2['default'].createElement('input', { type: 'text', placeholder: '' })
								),
								_react2['default'].createElement(
									'div',
									{ className: 'col-sm-4 r' },
									_react2['default'].createElement(
										'span',
										null,
										'Pincode:'
									),
									_react2['default'].createElement('input', { type: 'text', placeholder: '' })
								)
							),
							_react2['default'].createElement('input', { type: 'button', value: 'Next' })
						)
					)
				),
				_react2['default'].createElement(_Footer2['default'], null)
			);
		}
	}]);

	return AboutHome;
})(_react2['default'].Component);

AboutHome.contextTypes = {
	router: _react2['default'].PropTypes.func.isRequired
};

exports['default'] = AboutHome;
module.exports = exports['default'];

},{"../actions/AboutHomeActions":1,"../stores/AboutHomeStore":20,"./Footer":10,"./Header":12,"react":"react","react-router":"react-router"}],6:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var App = (function (_React$Component) {
  _inherits(App, _React$Component);

  function App() {
    _classCallCheck(this, App);

    _get(Object.getPrototypeOf(App.prototype), 'constructor', this).apply(this, arguments);
  }

  _createClass(App, [{
    key: 'render',
    value: function render() {
      return _react2['default'].createElement(
        'div',
        null,
        _react2['default'].createElement(_reactRouter.RouteHandler, null)
      );
    }
  }]);

  return App;
})(_react2['default'].Component);

exports['default'] = App;
module.exports = exports['default'];

},{"react":"react","react-router":"react-router"}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var Cart = (function (_React$Component) {
	_inherits(Cart, _React$Component);

	function Cart() {
		_classCallCheck(this, Cart);

		_get(Object.getPrototypeOf(Cart.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(Cart, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				null,
				'hello from cart'
			);
		}
	}]);

	return Cart;
})(_react2['default'].Component);

exports['default'] = Cart;
module.exports = exports['default'];

},{"react":"react"}],8:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Footer = require('./Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _Header = require('./Header');

var _Header2 = _interopRequireDefault(_Header);

var FAQ = (function (_React$Component) {
	_inherits(FAQ, _React$Component);

	function FAQ() {
		_classCallCheck(this, FAQ);

		_get(Object.getPrototypeOf(FAQ.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(FAQ, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'container-fluid' },
				_react2['default'].createElement(_Header2['default'], null),
				_react2['default'].createElement(
					'div',
					{ className: 'row faqs' },
					_react2['default'].createElement(
						'div',
						{ className: 'headerFaq' },
						_react2['default'].createElement(
							'label',
							null,
							'Frequentely Asked Questions'
						)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'questionTitle' },
						_react2['default'].createElement(
							'label',
							null,
							'About ',
							_react2['default'].createElement(
								'span',
								null,
								'On The House'
							)
						)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'panel-group', id: 'accordion', role: 'tablist', 'aria-multiselectable': 'true' },
						_react2['default'].createElement(
							'div',
							{ className: 'panel panel-default' },
							_react2['default'].createElement(
								'div',
								{ className: 'panel-heading', role: 'tab', id: 'headingOne' },
								_react2['default'].createElement(
									'h4',
									{ className: 'panel-title' },
									_react2['default'].createElement(
										'a',
										{ role: 'button', 'data-toggle': 'collapse', 'data-parent': '#accordion', href: '#collapseOne', 'aria-expanded': 'true', 'aria-controls': 'collapseOne' },
										_react2['default'].createElement('div', { className: 'circleFaq' }),
										'What is on the hOuse?'
									)
								)
							),
							_react2['default'].createElement(
								'div',
								{ id: 'collapseOne', className: 'panel-collapse collapse in', role: 'tabpanel', 'aria-labelledby': 'headingOne' },
								_react2['default'].createElement(
									'div',
									{ className: 'panel-body' },
									'An initiative from CF, where the seeker who has newly shortlisted and bought or rented a property through CF will be able to select the discount offers from our select branded partners in Home Improvement, Furniture, Furnishings , Home loan, Electronics space.'
								)
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'panel panel-default' },
							_react2['default'].createElement(
								'div',
								{ className: 'panel-heading', role: 'tab', id: 'headingTwo' },
								_react2['default'].createElement(
									'h4',
									{ className: 'panel-title' },
									_react2['default'].createElement(
										'a',
										{ className: 'collapsed', role: 'button', 'data-toggle': 'collapse', 'data-parent': '#accordion', href: '#collapseTwo', 'aria-expanded': 'false', 'aria-controls': 'collapseTwo' },
										_react2['default'].createElement('div', { className: 'circleFaq' }),
										'House Does it work?'
									)
								)
							),
							_react2['default'].createElement(
								'div',
								{ id: 'collapseTwo', className: 'panel-collapse collapse', role: 'tabpanel', 'aria-labelledby': 'headingTwo' },
								_react2['default'].createElement(
									'div',
									{ className: 'panel-body' },
									'When you find your house on CF, come to the OTH home page and give us the property details. Once it is verified, we would like to say thanks by offering discount coupons for your new home.'
								)
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'panel panel-default' },
							_react2['default'].createElement(
								'div',
								{ className: 'panel-heading', role: 'tab', id: 'headingThree' },
								_react2['default'].createElement(
									'h4',
									{ className: 'panel-title' },
									_react2['default'].createElement(
										'a',
										{ className: 'collapsed', role: 'button', 'data-toggle': 'collapse', 'data-parent': '#accordion', href: '#collapseThree', 'aria-expanded': 'false', 'aria-controls': 'collapseThree' },
										_react2['default'].createElement('div', { className: 'circleFaq' }),
										'Do i need to register to claim the coupons?'
									)
								)
							),
							_react2['default'].createElement(
								'div',
								{ id: 'collapseThree', className: 'panel-collapse collapse', role: 'tabpanel', 'aria-labelledby': 'headingThree' },
								_react2['default'].createElement(
									'div',
									{ className: 'panel-body' },
									'Yes, you must have an existing account to claim these coupon codes. You can also sign in from Facebook or Google+ account.'
								)
							)
						)
					)
				),
				_react2['default'].createElement(_Footer2['default'], null)
			);
		}
	}]);

	return FAQ;
})(_react2['default'].Component);

exports['default'] = FAQ;
module.exports = exports['default'];

},{"./Footer":10,"./Header":12,"react":"react"}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var FBLogin = (function (_React$Component) {
	_inherits(FBLogin, _React$Component);

	function FBLogin() {
		_classCallCheck(this, FBLogin);

		_get(Object.getPrototypeOf(FBLogin.prototype), "constructor", this).apply(this, arguments);
	}

	_createClass(FBLogin, [{
		key: "render",
		value: function render() {
			return _react2["default"].createElement(
				"div",
				{ className: "col-md-6" },
				_react2["default"].createElement(
					"center",
					null,
					_react2["default"].createElement(
						"div",
						{ className: "socialLogin" },
						_react2["default"].createElement("img", { src: "img/fb.png" }),
						_react2["default"].createElement("img", { src: "img/gp.png" }),
						_react2["default"].createElement(
							"span",
							null,
							"Don’t worry we won’t post anything without your permission"
						)
					),
					_react2["default"].createElement(
						"div",
						{ className: "socialLoginMobile" },
						_react2["default"].createElement(
							"center",
							null,
							_react2["default"].createElement(
								"div",
								{ className: "row" },
								_react2["default"].createElement(
									"div",
									{ className: "col-xs-6" },
									_react2["default"].createElement("img", { src: "img/mobileFb.png" })
								),
								_react2["default"].createElement(
									"div",
									{ className: "col-xs-6" },
									_react2["default"].createElement("img", { src: "img/mobileG.png" })
								)
							),
							_react2["default"].createElement(
								"div",
								{ className: "row permissopnMobile" },
								_react2["default"].createElement(
									"span",
									null,
									"Don’t worry we won’t post anything without your permission"
								)
							)
						)
					)
				)
			);
		}
	}]);

	return FBLogin;
})(_react2["default"].Component);

exports["default"] = FBLogin;
module.exports = exports["default"];

},{"react":"react"}],10:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var Footer = (function (_React$Component) {
	_inherits(Footer, _React$Component);

	function Footer() {
		_classCallCheck(this, Footer);

		_get(Object.getPrototypeOf(Footer.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(Footer, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'row OthFooterSection' },
				_react2['default'].createElement(
					'center',
					null,
					_react2['default'].createElement(
						'div',
						{ className: 'col-md-12 col-xs-12 footer1' },
						_react2['default'].createElement(
							'ul',
							null,
							_react2['default'].createElement(
								'li',
								null,
								_react2['default'].createElement(
									_reactRouter.Link,
									{ to: '/faq' },
									'FAQs'
								)
							),
							_react2['default'].createElement(
								'li',
								null,
								_react2['default'].createElement(
									_reactRouter.Link,
									{ to: '/privacypolicy' },
									'Privacy Policy'
								)
							),
							_react2['default'].createElement(
								'li',
								null,
								_react2['default'].createElement(
									_reactRouter.Link,
									{ to: '/howtoavail' },
									'How To Avail'
								)
							),
							_react2['default'].createElement(
								'li',
								null,
								_react2['default'].createElement(
									_reactRouter.Link,
									{ to: '/contact' },
									'Contact'
								)
							)
						)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'col-md-12 col-sm-12 footer2' },
						_react2['default'].createElement(
							'div',
							null,
							'Copyright © 2007-15 ',
							_react2['default'].createElement(
								'a',
								{ target: '_blank', href: 'http://www.commonfloor.com', style: { color: "#f68121" } },
								'CommonFloor.com'
							),
							'   All rights reserved.'
						)
					)
				)
			);
		}
	}]);

	return Footer;
})(_react2['default'].Component);

exports['default'] = Footer;
module.exports = exports['default'];

},{"react":"react","react-router":"react-router"}],11:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _actionsLoginFormActions = require('../actions/LoginFormActions');

var _actionsLoginFormActions2 = _interopRequireDefault(_actionsLoginFormActions);

var _storesLoginFormStore = require('../stores/LoginFormStore');

var _storesLoginFormStore2 = _interopRequireDefault(_storesLoginFormStore);

var FormLogin = (function (_React$Component) {
	_inherits(FormLogin, _React$Component);

	function FormLogin(props) {
		_classCallCheck(this, FormLogin);

		_get(Object.getPrototypeOf(FormLogin.prototype), 'constructor', this).call(this, props);
		this.state = _storesLoginFormStore2['default'].getState();
		this.onChange = this.onChange.bind(this);
	}

	_createClass(FormLogin, [{
		key: 'componentDidMount',
		value: function componentDidMount() {
			_storesLoginFormStore2['default'].listen(this.onChange);
		}
	}, {
		key: 'componentWillMount',
		value: function componentWillMount() {
			_storesLoginFormStore2['default'].unlisten(this.onChange);
		}
	}, {
		key: 'onChange',
		value: function onChange(state) {
			this.setState(state);
		}
	}, {
		key: 'handleSubmit',
		value: function handleSubmit() {

			var email = this.state.email.trim();
			var password = this.state.password;

			if (!email) {
				_actionsLoginFormActions2['default'].invalidEmail();
				this.refs.emailTextField.getDOMNode().focus();
			}

			if (!password) {
				_actionsLoginFormActions2['default'].invalidPassword();
				this.ref.passwordTextField.getDOMNode().focus();
			}

			if (email && password) {
				_actionsLoginFormActions2['default'].login({
					email: email,
					password: password,
					router: this.context.router
				});
			}
		}
	}, {
		key: 'handleSignUpRedirect',
		value: function handleSignUpRedirect() {
			_actionsLoginFormActions2['default'].signUp({ router: this.context.router });
		}
	}, {
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'col-md-6 l' },
				_react2['default'].createElement(
					'div',
					{ className: 'loginForm' },
					_react2['default'].createElement(
						'div',
						{ className: 'loginFormWrap' },
						_react2['default'].createElement(
							'p',
							{ style: { color: 'red' }, className: 'help-block' },
							this.state.helpBlock
						),
						_react2['default'].createElement('input', { type: 'text', ref: 'emailTextField', placeholder: 'Email id', value: this.state.email, onChange: _actionsLoginFormActions2['default'].updateEmail }),
						_react2['default'].createElement('input', { type: 'password', ref: 'passwordTextField', placeholder: 'password', value: this.state.password, onChange: _actionsLoginFormActions2['default'].updatePassword })
					),
					_react2['default'].createElement(
						'span',
						null,
						_react2['default'].createElement(
							'a',
							{ className: 'fp', href: '' },
							'Forgot Password?'
						)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'row' },
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-6 col-sm-6 signIn' },
							_react2['default'].createElement('input', { type: 'button', value: 'Sign In', onClick: this.handleSubmit.bind(this) }),
							_react2['default'].createElement(
								'span',
								null,
								'*mandatory fields'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-6 col-sm-6 signUp' },
							_react2['default'].createElement('input', { className: 'pull-right', type: 'button', value: 'Sign Up', onClick: this.handleSignUpRedirect.bind(this) }),
							_react2['default'].createElement(
								'span',
								null,
								'not registered yet?'
							)
						)
					),
					_react2['default'].createElement('div', { className: 'mandy' })
				)
			);
		}
	}]);

	return FormLogin;
})(_react2['default'].Component);

FormLogin.contextTypes = {
	router: _react2['default'].PropTypes.func.isRequired
};

exports['default'] = FormLogin;
module.exports = exports['default'];

},{"../actions/LoginFormActions":2,"../stores/LoginFormStore":21,"react":"react"}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var Header = (function (_React$Component) {
	_inherits(Header, _React$Component);

	function Header() {
		_classCallCheck(this, Header);

		_get(Object.getPrototypeOf(Header.prototype), "constructor", this).apply(this, arguments);
	}

	_createClass(Header, [{
		key: "render",
		value: function render() {
			return _react2["default"].createElement(
				"div",
				{ className: "row OthHeaderSection" },
				_react2["default"].createElement(
					"div",
					{ className: "header1" },
					_react2["default"].createElement(
						"div",
						{ className: "col-xs-6 col-md-6" },
						_react2["default"].createElement(
							"div",
							{ className: "col-sm-12 imgLogoWrap" },
							_react2["default"].createElement("img", { src: "img/oth_logo.jpg", style: { width: 35 + "%" } })
						)
					),
					_react2["default"].createElement("div", { className: "col-md-6 col-sm-6" })
				),
				_react2["default"].createElement(
					"div",
					{ className: "borderHeader" },
					_react2["default"].createElement("div", { className: "col-md-6 col-xs-6 orange" }),
					_react2["default"].createElement("div", { className: "col-md-6 col-xs-6 brown" })
				),
				_react2["default"].createElement("div", { className: "header2 " })
			);
		}
	}]);

	return Header;
})(_react2["default"].Component);

exports["default"] = Header;
module.exports = exports["default"];

},{"react":"react"}],13:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Footer = require('./Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _HomeCompanyLogos = require('./HomeCompanyLogos');

var _HomeCompanyLogos2 = _interopRequireDefault(_HomeCompanyLogos);

var _reactRouter = require('react-router');

var Home = (function (_React$Component) {
	_inherits(Home, _React$Component);

	function Home() {
		_classCallCheck(this, Home);

		_get(Object.getPrototypeOf(Home.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(Home, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'container-fluid ' },
				_react2['default'].createElement(
					'div',
					{ className: 'row homePage' },
					_react2['default'].createElement(
						'div',
						{ className: 'hpWrap' },
						_react2['default'].createElement('img', { className: 'bgImage img-responsive', src: 'img/Background.jpg' }),
						_react2['default'].createElement(
							'div',
							{ className: 'onTopHomeImage' },
							_react2['default'].createElement(
								'center',
								null,
								_react2['default'].createElement(
									'div',
									{ className: 'onTopHomeImageContent' },
									_react2['default'].createElement(
										'label',
										null,
										'Found a house via CommonFloor?',
										_react2['default'].createElement(
											'span',
											{ className: 'tagline' },
											'A whole bunch of free house warming gifts await you!'
										)
									),
									_react2['default'].createElement('img', { className: 'othLogo', src: 'img/oth_logo1.png' }),
									_react2['default'].createElement(
										'label',
										{ className: 'poweredBy' },
										' Powered By'
									),
									_react2['default'].createElement('img', { src: 'img/cf_logo.png' })
								)
							),
							_react2['default'].createElement(
								'div',
								{ className: 'companyLogosMobile' },
								_react2['default'].createElement(_HomeCompanyLogos2['default'], null)
							),
							_react2['default'].createElement(
								'div',
								{ className: 'circleHome' },
								_react2['default'].createElement(
									'center',
									null,
									_react2['default'].createElement(
										'a',
										{ href: '#HowTo' },
										_react2['default'].createElement('img', { src: 'img/circleH.png' })
									)
								)
							)
						)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'companyLogos' },
						_react2['default'].createElement(_HomeCompanyLogos2['default'], null)
					),
					_react2['default'].createElement(
						'div',
						{ className: 'howToavail', id: 'HowTo' },
						_react2['default'].createElement(
							'div',
							{ className: 'availHeader' },
							'Heres how to avail your gifts',
							_react2['default'].createElement('div', { className: 'col-md-6 col-xs-6 orange' }),
							_react2['default'].createElement('div', { className: 'col-md-6 col-xs-6 brown' })
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-12 col-md-6 tiles' },
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-3' },
								_react2['default'].createElement('img', { className: 'img-responsive', src: 'img/claimNow.png' })
							),
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-9 text' },
								'Go to "Claim Now" & submit your property details and documents'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-12 col-md-6  tiles' },
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-3' },
								_react2['default'].createElement('img', { className: 'img-responsive', src: 'img/browse.png' })
							),
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-9 text' },
								'Browse through the list of free offers'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-12 col-md-6  tiles' },
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-3' },
								_react2['default'].createElement('img', { className: 'img-responsive', src: 'img/cart.png' })
							),
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-9 text' },
								'Add the free offers you like to your cart & checkout'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-12 col-md-6  tiles' },
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-3' },
								_react2['default'].createElement('img', { className: 'img-responsive', src: 'img/post.png' })
							),
							_react2['default'].createElement(
								'div',
								{ className: 'col-xs-9 text' },
								'Post-verification (max 1 - 2 working days), you will receive the discount codes'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-md-12 aruready' },
							_react2['default'].createElement(
								'center',
								null,
								_react2['default'].createElement(
									'label',
									null,
									'Are you ready?'
								),
								_react2['default'].createElement(
									_reactRouter.Link,
									{ to: '/login' },
									'Claim Now'
								)
							)
						)
					)
				),
				_react2['default'].createElement(_Footer2['default'], null)
			);
		}
	}]);

	return Home;
})(_react2['default'].Component);

exports['default'] = Home;
module.exports = exports['default'];

},{"./Footer":10,"./HomeCompanyLogos":14,"react":"react","react-router":"react-router"}],14:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var HomeCompanyLogos = (function (_React$Component) {
	_inherits(HomeCompanyLogos, _React$Component);

	function HomeCompanyLogos() {
		_classCallCheck(this, HomeCompanyLogos);

		_get(Object.getPrototypeOf(HomeCompanyLogos.prototype), "constructor", this).apply(this, arguments);
	}

	_createClass(HomeCompanyLogos, [{
		key: "render",
		value: function render() {
			return _react2["default"].createElement(
				"center",
				null,
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-12 col-md-2 partners" },
					"Partner:"
				),
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-3 col-md-2" },
					_react2["default"].createElement("img", { className: "img-responsive", src: "img/ulLogo.png" })
				),
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-3 col-md-2" },
					_react2["default"].createElement("img", { className: "img-responsive", src: "img/homelane.png" })
				),
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-3 col-md-2" },
					_react2["default"].createElement("img", { className: "img-responsive", src: "img/furlenco.png" })
				),
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-3 col-md-2 hdfc" },
					_react2["default"].createElement("img", { className: "img-responsive", src: "img/hdfc.png" })
				),
				_react2["default"].createElement(
					"div",
					{ className: "col-xs-12 col-md-2 viewMore" },
					_react2["default"].createElement(
						"a",
						{ href: "" },
						"View more offers>>"
					)
				)
			);
		}
	}]);

	return HomeCompanyLogos;
})(_react2["default"].Component);

exports["default"] = HomeCompanyLogos;
module.exports = exports["default"];

},{"react":"react"}],15:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Header = require('./Header');

var _Header2 = _interopRequireDefault(_Header);

var _FBLogin = require('./FBLogin');

var _FBLogin2 = _interopRequireDefault(_FBLogin);

var _FormLogin = require('./FormLogin');

var _FormLogin2 = _interopRequireDefault(_FormLogin);

var _Footer = require('./Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var Login = (function (_React$Component) {
	_inherits(Login, _React$Component);

	function Login() {
		_classCallCheck(this, Login);

		_get(Object.getPrototypeOf(Login.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(Login, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'container-fluid loginPage' },
				_react2['default'].createElement(_Header2['default'], null),
				_react2['default'].createElement(
					'div',
					{ className: 'row othLogin' },
					_react2['default'].createElement(
						'div',
						{ className: 'col-md-12 loginhead' },
						'Sign in to edit your availed offers!'
					),
					_react2['default'].createElement(_FBLogin2['default'], null),
					_react2['default'].createElement(_FormLogin2['default'], null)
				),
				_react2['default'].createElement(_Footer2['default'], null)
			);
		}
	}]);

	return Login;
})(_react2['default'].Component);

exports['default'] = Login;
module.exports = exports['default'];

},{"./FBLogin":9,"./Footer":10,"./FormLogin":11,"./Header":12,"react":"react"}],16:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _Header = require('./Header');

var _Header2 = _interopRequireDefault(_Header);

var _Footer = require('./Footer');

var _Footer2 = _interopRequireDefault(_Footer);

var _FBLogin = require('./FBLogin');

var _FBLogin2 = _interopRequireDefault(_FBLogin);

var _SignUpForm = require('./SignUpForm');

var _SignUpForm2 = _interopRequireDefault(_SignUpForm);

var SignUp = (function (_React$Component) {
	_inherits(SignUp, _React$Component);

	function SignUp() {
		_classCallCheck(this, SignUp);

		_get(Object.getPrototypeOf(SignUp.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(SignUp, [{
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'container-fluid loginPage registerPage' },
				_react2['default'].createElement(_Header2['default'], null),
				_react2['default'].createElement(
					'div',
					{ className: 'row othLogin' },
					_react2['default'].createElement(
						'div',
						{ className: 'col-md-12 loginhead' },
						'Sign up to claim your free offer!'
					),
					_react2['default'].createElement(_FBLogin2['default'], null),
					_react2['default'].createElement(_SignUpForm2['default'], null)
				),
				_react2['default'].createElement(_Footer2['default'], null)
			);
		}
	}]);

	return SignUp;
})(_react2['default'].Component);

exports['default'] = SignUp;
module.exports = exports['default'];

},{"./FBLogin":9,"./Footer":10,"./Header":12,"./SignUpForm":17,"react":"react"}],17:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; desc = parent = getter = undefined; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _actionsSignUpFormActions = require('../actions/SignUpFormActions');

var _actionsSignUpFormActions2 = _interopRequireDefault(_actionsSignUpFormActions);

var _storesSignUpFormStore = require('../stores/SignUpFormStore');

var _storesSignUpFormStore2 = _interopRequireDefault(_storesSignUpFormStore);

var SignUpForm = (function (_React$Component) {
	_inherits(SignUpForm, _React$Component);

	function SignUpForm(props) {
		_classCallCheck(this, SignUpForm);

		_get(Object.getPrototypeOf(SignUpForm.prototype), 'constructor', this).call(this, props);
		this.state = _storesSignUpFormStore2['default'].getState();
		this.onChange = this.onChange.bind(this);
	}

	_createClass(SignUpForm, [{
		key: 'componentDidMount',
		value: function componentDidMount() {
			_storesSignUpFormStore2['default'].listen(this.onChange);
		}
	}, {
		key: 'componentWillMount',
		value: function componentWillMount() {
			_storesSignUpFormStore2['default'].unlisten(this.onChange);
		}
	}, {
		key: 'onChange',
		value: function onChange(state) {
			this.setState(state);
		}
	}, {
		key: 'handleSubmit',
		value: function handleSubmit() {
			var name = this.state.username.trim();
			var email = this.state.email.trim();
			var password = this.state.password;
			var number = this.state.number;

			if (!name) {
				console.log("here");
				_actionsSignUpFormActions2['default'].invalidUsername();
				this.ref.nameTextField.getDOMNode().focus();
			}

			if (!email) {
				_actionsSignUpFormActions2['default'].invalidEmail();
				this.refs.emailTextField.getDOMNode().focus();
			}

			if (!password) {
				_actionsSignUpFormActions2['default'].invalidPassword();
				this.ref.passwordTextField.getDOMNode().focus();
			}

			if (!number) {
				_actionsSignUpFormActions2['default'].invalidNumber();
				this.ref.numberTextField.getDOMNode().focus();
			}

			if (email && password && number && name) {
				_actionsSignUpFormActions2['default'].signup({
					name: name,
					email: email,
					password: password,
					number: number,
					router: this.context.router
				});
			}
		}
	}, {
		key: 'handleLoginRedirect',
		value: function handleLoginRedirect() {
			_actionsSignUpFormActions2['default'].login({ router: this.context.router });
		}
	}, {
		key: 'render',
		value: function render() {
			return _react2['default'].createElement(
				'div',
				{ className: 'col-md-6 l' },
				_react2['default'].createElement(
					'div',
					{ className: 'loginForm' },
					_react2['default'].createElement(
						'div',
						{ className: 'loginFormWrap' },
						_react2['default'].createElement(
							'p',
							{ style: { color: 'red' }, className: 'help-block' },
							this.state.helpBlock
						),
						_react2['default'].createElement('input', { type: 'text', ref: 'nameTextField', placeholder: 'Full Name', value: this.state.username, onChange: _actionsSignUpFormActions2['default'].updateUsername }),
						_react2['default'].createElement('input', { type: 'text', ref: 'emailTextField', placeholder: 'Email id', value: this.state.email, onChange: _actionsSignUpFormActions2['default'].updateEmail }),
						_react2['default'].createElement('input', { type: 'password', ref: 'passwordTextField', placeholder: 'password', value: this.state.password, onChange: _actionsSignUpFormActions2['default'].updatePassword }),
						_react2['default'].createElement('input', { type: 'text', ref: 'numberTextField', placeholder: 'Mobile No', value: this.state.number, onChange: _actionsSignUpFormActions2['default'].updateNumber })
					),
					_react2['default'].createElement(
						'div',
						{ className: 'row' },
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-6 col-sm-6 signIn' },
							_react2['default'].createElement('input', { type: 'button', value: 'Sign Up', onClick: this.handleSubmit.bind(this) }),
							_react2['default'].createElement(
								'span',
								null,
								'*mandatory fields'
							)
						),
						_react2['default'].createElement(
							'div',
							{ className: 'col-xs-6 col-sm-6 signUp' },
							_react2['default'].createElement('input', { className: 'pull-right', type: 'button', value: 'Sign In', onClick: this.handleLoginRedirect.bind(this) }),
							_react2['default'].createElement(
								'span',
								null,
								'Already registered?'
							)
						)
					),
					_react2['default'].createElement('div', { className: 'mandy' })
				)
			);
		}
	}]);

	return SignUpForm;
})(_react2['default'].Component);

SignUpForm.contextTypes = {
	router: _react2['default'].PropTypes.func.isRequired
};

exports['default'] = SignUpForm;
module.exports = exports['default'];

},{"../actions/SignUpFormActions":3,"../stores/SignUpFormStore":22,"react":"react"}],18:[function(require,module,exports){
'use strict';

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _reactRouter2 = _interopRequireDefault(_reactRouter);

var _routes = require('./routes');

var _routes2 = _interopRequireDefault(_routes);

_reactRouter2['default'].run(_routes2['default'], _reactRouter2['default'].HistoryLocation, function (Handler) {
  _react2['default'].render(_react2['default'].createElement(Handler, null), document.getElementById('app'));
});

},{"./routes":19,"react":"react","react-router":"react-router"}],19:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRouter = require('react-router');

var _componentsApp = require('./components/App');

var _componentsApp2 = _interopRequireDefault(_componentsApp);

var _componentsHome = require('./components/Home');

var _componentsHome2 = _interopRequireDefault(_componentsHome);

var _componentsLogin = require('./components/Login');

var _componentsLogin2 = _interopRequireDefault(_componentsLogin);

var _componentsCart = require('./components/Cart');

var _componentsCart2 = _interopRequireDefault(_componentsCart);

var _componentsSignUp = require('./components/SignUp');

var _componentsSignUp2 = _interopRequireDefault(_componentsSignUp);

var _componentsFAQ = require('./components/FAQ');

var _componentsFAQ2 = _interopRequireDefault(_componentsFAQ);

var _componentsAboutHome = require('./components/AboutHome');

var _componentsAboutHome2 = _interopRequireDefault(_componentsAboutHome);

exports['default'] = _react2['default'].createElement(
  _reactRouter.Route,
  { handler: _componentsApp2['default'] },
  _react2['default'].createElement(_reactRouter.Route, { path: '/', handler: _componentsHome2['default'] }),
  _react2['default'].createElement(_reactRouter.Route, { path: '/login', handler: _componentsLogin2['default'] }),
  _react2['default'].createElement(_reactRouter.Route, { path: '/cart', handler: _componentsCart2['default'] }),
  _react2['default'].createElement(_reactRouter.Route, { path: '/signup', handler: _componentsSignUp2['default'] }),
  _react2['default'].createElement(_reactRouter.Route, { path: '/faq', handler: _componentsFAQ2['default'] }),
  _react2['default'].createElement(_reactRouter.Route, { path: '/aboutyourhome/:id', handler: _componentsAboutHome2['default'] })
);
module.exports = exports['default'];

},{"./components/AboutHome":5,"./components/App":6,"./components/Cart":7,"./components/FAQ":8,"./components/Home":13,"./components/Login":15,"./components/SignUp":16,"react":"react","react-router":"react-router"}],20:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _actionsAboutHomeActions = require('../actions/AboutHomeActions');

var _actionsAboutHomeActions2 = _interopRequireDefault(_actionsAboutHomeActions);

var AboutHomeStore = (function () {
	function AboutHomeStore() {
		_classCallCheck(this, AboutHomeStore);

		this.bindActions(_actionsAboutHomeActions2['default']);
		this.name = '';
		this.helpBlock = '';
	}

	_createClass(AboutHomeStore, [{
		key: 'onGetName',
		value: function onGetName(payload) {
			this.name = payload.username;
		}
	}]);

	return AboutHomeStore;
})();

exports['default'] = _alt2['default'].createStore(AboutHomeStore);
module.exports = exports['default'];

},{"../actions/AboutHomeActions":1,"../alt":4}],21:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _actionsLoginFormActions = require('../actions/LoginFormActions');

var _actionsLoginFormActions2 = _interopRequireDefault(_actionsLoginFormActions);

var LoginFormStore = (function () {
	function LoginFormStore() {
		_classCallCheck(this, LoginFormStore);

		this.bindActions(_actionsLoginFormActions2['default']);
		this.email = '';
		this.password = '';
		this.helpBlock = '';
	}

	_createClass(LoginFormStore, [{
		key: 'onLoginFormSuccess',
		value: function onLoginFormSuccess(successData) {
			successData.router.transitionTo('/aboutyourhome/' + successData.message.userId);
		}
	}, {
		key: 'onLoginFormFail',
		value: function onLoginFormFail(errorMessage) {
			this.nameVaidationState = 'has-error';
			this.helpBlock = errorMessage;
		}
	}, {
		key: 'onInvalidEmail',
		value: function onInvalidEmail() {
			this.helpBlock = 'Please Enter an Email id';
		}
	}, {
		key: 'onInvalidPassword',
		value: function onInvalidPassword() {
			this.helpBlock = 'Please Enter a Password';
		}
	}, {
		key: 'onUpdateEmail',
		value: function onUpdateEmail(event) {
			this.helpBlock = '';
			this.email = event.target.value;
		}
	}, {
		key: 'onUpdatePassword',
		value: function onUpdatePassword(event) {
			this.helpBlock = '';
			this.password = event.target.value;
		}
	}, {
		key: 'onSignUp',
		value: function onSignUp(redirect) {
			redirect.router.transitionTo('/signup');
		}
	}]);

	return LoginFormStore;
})();

exports['default'] = _alt2['default'].createStore(LoginFormStore);
module.exports = exports['default'];

},{"../actions/LoginFormActions":2,"../alt":4}],22:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _alt = require('../alt');

var _alt2 = _interopRequireDefault(_alt);

var _actionsSignUpFormActions = require('../actions/SignUpFormActions');

var _actionsSignUpFormActions2 = _interopRequireDefault(_actionsSignUpFormActions);

var SignUpFormStore = (function () {
	function SignUpFormStore() {
		_classCallCheck(this, SignUpFormStore);

		this.bindActions(_actionsSignUpFormActions2['default']);
		this.email = '';
		this.password = '';
		this.number = '';
		this.username = '';
		this.helpBlock = '';
	}

	_createClass(SignUpFormStore, [{
		key: 'onSignUpFormSuccess',
		value: function onSignUpFormSuccess(successData) {
			successData.router.transitionTo('/login');
		}
	}, {
		key: 'onSignUpFormFail',
		value: function onSignUpFormFail(errorMessage) {
			this.nameVaidationState = 'has-error';
			this.helpBlock = errorMessage;
		}
	}, {
		key: 'onInvalidEmail',
		value: function onInvalidEmail() {
			this.helpBlock = 'Please Enter an Email id';
		}
	}, {
		key: 'onInvalidPassword',
		value: function onInvalidPassword() {
			this.helpBlock = 'Please Enter a Password';
		}
	}, {
		key: 'onInvalidNumber',
		value: function onInvalidNumber() {
			this.helpBlock = 'Please Enter a Number';
		}
	}, {
		key: 'onInvalidUsername',
		value: function onInvalidUsername() {
			this.helpBlock = 'Please Enter a Name';
		}
	}, {
		key: 'onUpdateEmail',
		value: function onUpdateEmail(event) {
			this.helpBlock = '';
			this.email = event.target.value;
		}
	}, {
		key: 'onUpdatePassword',
		value: function onUpdatePassword(event) {
			this.helpBlock = '';
			this.password = event.target.value;
		}
	}, {
		key: 'onUpdateUsername',
		value: function onUpdateUsername(event) {
			this.helpBlock = '';
			this.username = event.target.value;
		}
	}, {
		key: 'onUpdateNumber',
		value: function onUpdateNumber(event) {
			this.helpBlock = '';
			this.number = event.target.value;
		}
	}, {
		key: 'onLogin',
		value: function onLogin(redirect) {
			redirect.router.transitionTo('/login');
		}
	}]);

	return SignUpFormStore;
})();

exports['default'] = _alt2['default'].createStore(SignUpFormStore);
module.exports = exports['default'];

},{"../actions/SignUpFormActions":3,"../alt":4}]},{},[18]);
