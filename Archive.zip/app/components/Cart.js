import React from 'react';

class Cart extends React.Component {
	render() {
		return(
			<div>hello from cart</div>
			);
	}
}

export default Cart;