import alt from '../alt';
import AboutHomeActions from '../actions/AboutHomeActions';

class AboutHomeStore {
	constructor() {
		this.bindActions(AboutHomeActions);
		this.name = '';
		this.helpBlock = '';
	}

	onGetName(payload) {
		this.name = payload.username;
	}
}

export default alt.createStore(AboutHomeStore);