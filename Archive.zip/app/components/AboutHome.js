import React from 'react';
import Header from './Header';
import Footer from './Footer';
import Router from 'react-router';
import AboutHomeStore from '../stores/AboutHomeStore';
import AboutHomeActions from '../actions/AboutHomeActions';

class AboutHome extends React.Component {

	constructor(props) {
		super(props);
		this.state = AboutHomeStore.getState();
		this.onChange = this.onChange.bind(this);
	}

	componentDidMount() {
		AboutHomeStore.listen(this.onChange);
		AboutHomeActions.getUser({userId:this.props.params.id});
	}

	componentWillMount() {
		AboutHomeStore.unlisten(this.onChange);	
	}

	componentDidUpdate(prevProps) {
	    if (prevProps.params.id !== this.props.params.id) {
	      AboutHomeActions.getUser({userId:this.props.params.id});
	    }
  	}

  	onChange(state) {
    	this.setState(state);
  	}

	render() {
		return(
			<div className="container-fluid loginPage registerPage">
				<Header />
				<div className="row pDetails">
					<div className="pDetailsInnerWrapper">
						<center>
							<ul>
								<li className="activeLiPdetails">About Your Home</li>
								<li>Documentation</li>
								<li>Your Contact @ CF</li>
							</ul>
						</center>
						<div className="col-sm-12 aboutYourHome" >
							<label>Hi {this.state.name}, to start with tell us about your new home</label>
							<div className="formWrap">
								<span>Address Line 1:</span>
								<input type="text" placeholder="" />
								<span>Address Line 1:</span>
								<input type="text" placeholder="" />
								<div className="col-sm-4 l">
										<span>Town/City:</span>
										<input type="text" placeholder="" />
								</div>
								<div className="col-sm-4">
										<span>State:</span>
										<input type="text" placeholder="" />
								</div>
								<div className="col-sm-4 r">
										<span>Pincode:</span>
										<input type="text" placeholder="" />
								</div>
								
							</div>
							<input type="button" value="Next" />
						</div>
					</div>
				</div>
				<Footer />
			</div>
			);
	}
}

AboutHome.contextTypes = {
 router: React.PropTypes.func.isRequired
};

export default AboutHome;