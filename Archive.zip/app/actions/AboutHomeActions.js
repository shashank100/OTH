import alt from '../alt';
import {assign} from 'underscore';
class AboutHomeActions {
	constructor() {
		this.generateActions(
				'getName'
			);
	}

	getUser(credentials) {
		$.ajax({
			type: 'POST',
			url: '/getUserInfo',
			data: {id: credentials.userId}
		})
		  .done((data) => {
		  	if(data.exist == false) {
		  		//handle redirect, user does not exist
		  	}
		  	else {
		  		AboutHomeStore.getName(data);
		  	}
		  })
		  .fail((jqXhr) => {
		  	this.actions.loginFormFail(data.message);
		  });
	}
}

export default alt.createActions(AboutHomeActions);